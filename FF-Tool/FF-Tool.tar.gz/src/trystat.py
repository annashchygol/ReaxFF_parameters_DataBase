# decide what are the statitical values to be gather: [use: numpy]
import numpy as np

a = np.array([1,2,3])
print np.percentile(a,50)
print np.percentile(a, [25, 75])
np.amin(a)
np.amax(a)